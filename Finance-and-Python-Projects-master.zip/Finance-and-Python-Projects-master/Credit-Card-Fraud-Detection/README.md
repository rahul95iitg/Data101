# Credit Card Fraud Detection with Machine Learning

## Included Techniques-

- Exploratory Data Analysis
- Dimensionality Reduction
- Visulaisation
- Modelling ( Multiple Classificatrion Models )
- Evaluation ( From Accuracy_Score to AUC_ROC Score )
