# Images for Understanding CCFD
